package com.kk.ecom.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.kk.ecom.entity.Product;


@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {
	
	public List<Product> findByProductnameContainsOrCategorynameContains(String productname,String categoryname);
	
	@Query(value="select p.productname from product p where p.product_id= :productId", nativeQuery = true)
	String findProductNameByProductId(@Param("productId") Long productId);
	

}
