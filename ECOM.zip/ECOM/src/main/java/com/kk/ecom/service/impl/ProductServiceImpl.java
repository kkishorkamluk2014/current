package com.kk.ecom.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kk.ecom.dto.ProductDto;
import com.kk.ecom.entity.Product;
import com.kk.ecom.repository.ProductRepository;
import com.kk.ecom.service.ProductService;

@Service
public class ProductServiceImpl implements ProductService {
	
	@Autowired
	ProductRepository productRepository;
	@Override
	public ProductDto addProducts(ProductDto productDto) {
		  Product product=new Product(); 
		  BeanUtils.copyProperties(productDto, product);
		  productRepository.save(product); 
		  return productDto; 
	}	
	@Override
	public List<Product> getAllProductsByNames(String productname, String categoryname) {
		
		List<Product> productList= new ArrayList<>();
		productList=productRepository.findByProductnameContainsOrCategorynameContains(productname, categoryname);
		return productList;
	}
	@Override
	public Product getProductById(Long product_Id) {

		Optional<Product> product=productRepository.findById(product_Id);
		if(product.isPresent())
		{
			return product.get();
		}
		return null;
	}
}
