package com.kk.ecom.controller;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kk.ecom.dto.OrderDto;
import com.kk.ecom.dto.OrderResponseDto;
import com.kk.ecom.entity.Order_details;
import com.kk.ecom.entity.Product;
import com.kk.ecom.service.OrderService;
import com.kk.ecom.service.impl.ProductServiceImpl;

/**
 * @author Kishor.Kamlu
 *
 */
@RestController
@RequestMapping("/orders")
public class OrderController {
	Logger logger=LoggerFactory.getLogger(OrderController.class);
	@Autowired
	OrderService orderService;
	
	@Autowired
	ProductServiceImpl productServiceImp;
	
	/**
	 * @param user_Id
	 * @return getOrderDetailsById
	 */
	@GetMapping("/{user_Id}")
	public List<OrderResponseDto> getOrderDetailsById(@PathVariable Long user_Id){
		
		return orderService.getOrderDetailsById(user_Id);
	}
	/**
	 * @param Order_Details
	 * @return OrderProduct
	 */
	@PostMapping
	public OrderDto orderProduct(@RequestBody OrderDto orderDto) {
		
		return orderService.orderProduct(orderDto);
		/*
		 * Product product=null; Order_details orderDetails=new Order_details();
		 * product=productServiceImp.getProductById(orderDto.getProduct().getProduct_Id(
		 * )); logger.info("Product Object"+product);
		 * orderDetails.setPrice(product.getPrice());
		 * orderDetails.setQuantity(orderDto.getProduct().getQuantity());
		 * orderDetails.setUser_Id(orderDto.getUser_Id());
		 * orderDetails.setProduct(product);
		 * orderDetails.setAccountNo(orderDto.getAccountNo()); double
		 * total=orderDetails.getPrice()*orderDetails.getQuantity();
		 * orderDetails.setDate(orderDto.getDate()); orderDetails.setTotal_price(total);
		 * product.setQuantity(product.getQuantity()-orderDetails.getQuantity());
		 * orderDetails= orderService.orderProduct(orderDetails);
		 */
		
	}
}
