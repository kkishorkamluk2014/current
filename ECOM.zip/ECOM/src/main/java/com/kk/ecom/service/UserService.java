package com.kk.ecom.service;

import com.kk.ecom.dto.UserDto;

public interface UserService {

	public UserDto saveUserDetails(UserDto userDto);
}
