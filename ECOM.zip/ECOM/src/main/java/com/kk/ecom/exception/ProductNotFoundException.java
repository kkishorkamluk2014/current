package com.kk.ecom.exception;

public class ProductNotFoundException extends RuntimeException{
	
	public ProductNotFoundException(String errorMessage) {
		super(errorMessage);
	}

}
