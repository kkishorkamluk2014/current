package com.kk.ecom.entity;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotEmpty;

import org.springframework.stereotype.Component;


@Entity
@Component
public class Order_details {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long order_Details_id;
	@OneToOne (cascade = CascadeType.MERGE)
	private Product product;
	//private Long productId;
	private int quantity;
	private double price;
	private Long user_Id;
	private Long accountNo;
	private LocalDate date;
	private Double total_price;
		
	
	
	
	
	/*
	 * public Long getProductId() { return productId; } public void
	 * setProductId(Long productId) { this.productId = productId; }
	 */
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public Double getTotal_price() {
		return total_price;
	}
	public void setTotal_price(Double total_price) {
		this.total_price = total_price;
	}
	public Long getOrder_Details_id() {
		return order_Details_id;
	}
	public void setOrder_Details_id(Long order_Details_id) {
		this.order_Details_id = order_Details_id;
	}
	
	public Long getUser_Id() {
		return user_Id;
	}
	public void setUser_Id(Long user_Id) {
		this.user_Id = user_Id;
	}
	public Long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(Long accountNo) {
		this.accountNo = accountNo;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	
}
