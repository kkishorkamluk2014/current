package com.kk.ecom.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.kk.ecom.dto.OrderDto;
import com.kk.ecom.dto.OrderResponseDto;
import com.kk.ecom.entity.Order_details;


@Service
public interface OrderService {

	OrderDto orderProduct(OrderDto orderDto);

	public List<OrderResponseDto> getOrderDetailsById(Long user_Id);

}
