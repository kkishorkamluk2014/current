package com.kk.ecom.service.impl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kk.ecom.dto.OrderDto;
import com.kk.ecom.dto.OrderResponseDto;
import com.kk.ecom.entity.Order_details;
import com.kk.ecom.entity.Product;
import com.kk.ecom.repository.OrderRepository;
import com.kk.ecom.repository.ProductRepository;
import com.kk.ecom.repository.UserRepository;
import com.kk.ecom.service.OrderService;



@Service
public class OrderServiceImpl implements OrderService {
	
	private static final Logger logger = LoggerFactory.getLogger(OrderServiceImpl.class);
	
	@Autowired
	OrderRepository orderRepository;
	@Autowired
	UserRepository userRepository;
	@Autowired
	ProductRepository productRepository;
	@Autowired
	ProductServiceImpl productServiceImpl;
		
	@Override
	public OrderDto orderProduct(OrderDto orderDto) {

		  Order_details orderDetails=new Order_details();
		  Product product=productServiceImpl.getProductById(orderDetails.getProduct().getProduct_Id()); 
		  logger.info("Product Object"+product);
		  orderDetails.setPrice(orderDetails.getProduct().getPrice());
		  orderDetails.setQuantity(orderDetails.getProduct().getQuantity());
		  orderDetails.setUser_Id(orderDetails.getUser_Id());
		  orderDetails.setProduct(product);
		  orderDetails.setAccountNo(orderDetails.getAccountNo()); 
		  double total=orderDetails.getPrice()*orderDetails.getQuantity();
		  orderDetails.setDate(orderDetails.getDate()); 
		  orderDetails.setTotal_price(total);
		  product.setQuantity(product.getQuantity()-orderDetails.getQuantity());
		  
		  BeanUtils.copyProperties(orderDetails, orderDto);
		  
		  Order_details orderPlaced=orderRepository.save(orderDetails);
		
		return orderDto;
	}
	@Override
	public List<OrderResponseDto> getOrderDetailsById(Long user_Id) {
		
		List<Order_details> orderList=orderRepository.findByProduct(user_Id);
	
		return	orderList.stream().map(order -> getOrdersResponse(order)).collect(Collectors.toList());
	
	}
	private OrderResponseDto getOrdersResponse(Order_details orderDetails) {
		OrderResponseDto responseDto = new OrderResponseDto();
		BeanUtils.copyProperties(orderDetails, responseDto);
		responseDto.setProductName(productRepository.findProductNameByProductId(orderDetails.getProduct().getProduct_Id()));
		return responseDto;
	}
}


