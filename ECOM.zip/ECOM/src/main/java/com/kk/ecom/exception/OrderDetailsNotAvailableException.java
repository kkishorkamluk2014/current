package com.kk.ecom.exception;

public class OrderDetailsNotAvailableException extends RuntimeException {
	
	OrderDetailsNotAvailableException(String errorMessage)
	{
		super(errorMessage);
	}

}
