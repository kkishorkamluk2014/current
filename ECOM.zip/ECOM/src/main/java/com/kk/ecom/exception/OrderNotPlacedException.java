package com.kk.ecom.exception;


public class OrderNotPlacedException extends RuntimeException {
    
    public OrderNotPlacedException(String errorMessage){
        super(errorMessage);
    }
}
 