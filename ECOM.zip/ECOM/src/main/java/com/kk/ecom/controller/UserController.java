package com.kk.ecom.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kk.ecom.dto.UserDto;
import com.kk.ecom.service.UserService;

/**
 * @author Kishor.Kamlu
 *
 */
@RestController
@RequestMapping("/users")
public class UserController {
	
	Logger logger=LoggerFactory.getLogger(UserController.class);
	@Autowired
	UserService userService;
	
	/**
	 * @param UserDto
	 * @return saveUserDetails(userDto)
	 */
	@PostMapping
	@Valid
	public UserDto saveUserDetails(@Valid @RequestBody UserDto userDto) {
		logger.info("User Details saved ");
		return userService.saveUserDetails(userDto);
	}
}
