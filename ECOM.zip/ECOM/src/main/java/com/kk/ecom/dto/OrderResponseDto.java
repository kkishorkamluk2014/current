package com.kk.ecom.dto;

import java.time.LocalDate;

public class OrderResponseDto {
	
	private Long user_Id;
	private Long Order_Details_id;
	private Long accountNo;
	private LocalDate date;
	private String productName;
	private int quantity;
	private Double total_price;
	public Long getOrder_Details_id() {
		return Order_Details_id;
	}
	public void setOrder_Details_id(Long order_Details_id) {
		Order_Details_id = order_Details_id;
	}
	
	
	public Long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(Long accountNo) {
		this.accountNo = accountNo;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Double getTotal_price() {
		return total_price;
	}
	public void setTotal_price(Double total_price) {
		this.total_price = total_price;
	}
	
		
}
