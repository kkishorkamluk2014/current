package com.kk.ecom.entity;
/*
 * 
 */
import java.sql.Date;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

import org.hibernate.annotations.ManyToAny;
@Entity
@Table (name = "orders")
public class Order {
	
	 @Id
	 @GeneratedValue (strategy = GenerationType.IDENTITY)
	 private Long order_Id;
	 @NotEmpty(message="Date mandatory")
	 private LocalDate date;
	 private LocalTime time;
	 @NotEmpty(message="Total Price")
	 private double total_Price;
	public Long getOrder_Id() {
		return order_Id;
	}
	public void setOrder_Id(Long order_Id) {
		this.order_Id = order_Id;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public LocalTime getTime() {
		return time;
	}
	public void setTime(LocalTime time) {
		this.time = time;
	}
	public double getTotal_Price() {
		return total_Price;
	}
	public void setTotal_Price(double total_Price) {
		this.total_Price = total_Price;
	}
}
