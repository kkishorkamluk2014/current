package com.kk.ecom.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.kk.ecom.entity.Order_details;



@Repository
public interface OrderRepository extends JpaRepository<Order_details, Long> {
	
	@Query(value = "SELECT t.* FROM order_details t WHERE t.user_id = :user_Id",nativeQuery=true)
	List<Order_details> findByProduct(Long user_Id);

}
