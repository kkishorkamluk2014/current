package com.kk.ecom.dto;
import java.time.LocalDate;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

/**
 * @author Kishor.Kamlu
 *
 */
public class OrderDto {
	
	private Long userId;
	private Long accountno;
	private LocalDate date;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "user_id")
	List<ProductRequestDto> products;
	//Getter
	//Setter
	
	public Long getUserId() {
		return userId;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public Long getAccountno() {
		return accountno;
	}
	public void setAccountno(Long accountno) {
		this.accountno = accountno;
	}
	public List<ProductRequestDto> getProducts() {
		return products;
	}
	public void setProducts(List<ProductRequestDto> products) {
		this.products = products;
	}
	
	
}
