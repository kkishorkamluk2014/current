package com.kk.ecom.service.impl;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kk.ecom.dto.UserDto;
import com.kk.ecom.entity.User;
import com.kk.ecom.repository.UserRepository;
import com.kk.ecom.service.UserService;


@Service
public class UserServiceImpl implements UserService{

	@Autowired
	UserRepository userRepository;
	@Override
	public UserDto saveUserDetails(UserDto userDto) {
		User user=new User(); 
		  BeanUtils.copyProperties(userDto, user);
		  userRepository.save(user); 
		  return userDto; 
	}

}
