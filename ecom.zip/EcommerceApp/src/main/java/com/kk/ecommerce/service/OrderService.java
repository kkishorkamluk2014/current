package com.kk.ecommerce.service;

import org.springframework.stereotype.Service;

import com.kk.ecommerce.dto.OrderDto;
import com.kk.ecommerce.entity.Order_details;



@Service
public interface OrderService {

	Order_details orderProduct(Order_details orderDto);

	public Order_details getOrderDetailsById(Long user_Id);

}
