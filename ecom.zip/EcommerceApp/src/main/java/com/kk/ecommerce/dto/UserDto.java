package com.kk.ecommerce.dto;


public class UserDto {

	private String f_Name;
	private String l_Name;
	private Long phone_No;
	private String email;
	private String password;
	
	public String getF_Name() {
		return f_Name;
	}
	public void setF_Name(String f_Name) {
		this.f_Name = f_Name;
	}
	public String getL_Name() {
		return l_Name;
	}
	public void setL_Name(String l_Name) {
		this.l_Name = l_Name;
	}
	public Long getPhone_No() {
		return phone_No;
	}
	public void setPhone_No(Long phone_No) {
		this.phone_No = phone_No;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
