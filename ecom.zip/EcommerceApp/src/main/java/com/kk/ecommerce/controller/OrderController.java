package com.kk.ecommerce.controller;


import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kk.ecommerce.entity.Order_details;
import com.kk.ecommerce.entity.Product;
import com.kk.ecommerce.service.OrderService;
import com.kk.ecommerce.service.impl.ProductServiceImpl;


@RestController
@RequestMapping("/orders")
public class OrderController {
	Logger logger=LoggerFactory.getLogger(OrderController.class);
	@Autowired
	OrderService orderService;
	
	@Autowired
	ProductServiceImpl productServiceImp;
	

	@GetMapping("/{user_Id}")
	public Order_details getOrderDetailsById(@PathVariable Long user_Id){
		
		return orderService.getOrderDetailsById(user_Id);
	}

	
	
	@PostMapping
	public ResponseEntity<?> orderProduct(@RequestBody Order_details orderDto) {
		Product product=null;
			
		Order_details orderDetails=new Order_details();
		product=productServiceImp.getProductById(orderDto.getProduct().getProduct_Id());
		logger.info("Product Object"+product);
		orderDetails.setPrice(product.getPrice());
		orderDetails.setQuantity(orderDto.getProduct().getQuantity());
		orderDetails.setUser_Id(orderDto.getUser_Id());
		orderDetails.setProduct(product);
		orderDetails.setAccountNo(orderDto.getAccountNo());
		
		double total=orderDetails.getPrice()*orderDetails.getQuantity();
		
		orderDetails.setDate(orderDto.getDate());
		orderDetails.setTotal_price(total);
		
		logger.info("-----------------------------------------------------------------------");
		orderDetails= orderService.orderProduct(orderDetails);
		logger.info("=================================================================================");
		if(orderDetails!=null) 
		{
			return new ResponseEntity<String>("Order Placed Successfully",HttpStatus.CREATED );
		}
		else 
		{
			return new ResponseEntity<String>("Did not placed Order",HttpStatus.NOT_FOUND );		
		}
	}

}
