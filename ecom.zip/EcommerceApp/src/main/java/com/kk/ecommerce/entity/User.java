package com.kk.ecommerce.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Entity
public class User {
	@Id
    @GeneratedValue (strategy = GenerationType.IDENTITY)
	private Long user_Id;
	
	@NotNull(message="Enter First Name")
	private String f_Name;
	@NotNull(message="Enter Last Name")
	private String l_Name;
	private Long phone_No;
	@Email
	@NotNull(message="Email id should not be empty")
	private String email;
	@NotNull(message="Please Enter Password")
	private String password;
	public Long getUser_Id() {
		return user_Id;
	}
	public void setUser_Id(Long user_Id) {
		this.user_Id = user_Id;
	}
	public String getF_Name() {
		return f_Name;
	}
	public void setF_Name(String f_Name) {
		this.f_Name = f_Name;
	}
	public String getL_Name() {
		return l_Name;
	}
	public void setL_Name(String l_Name) {
		this.l_Name = l_Name;
	}
	public Long getPhone_No() {
		return phone_No;
	}
	public void setPhone_No(Long phone_No) {
		this.phone_No = phone_No;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
	

}
