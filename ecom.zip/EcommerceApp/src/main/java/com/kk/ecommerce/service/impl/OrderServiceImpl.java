package com.kk.ecommerce.service.impl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.kk.ecommerce.dto.OrderDto;
import com.kk.ecommerce.entity.Order;
import com.kk.ecommerce.entity.Order_details;
import com.kk.ecommerce.entity.Product;
import com.kk.ecommerce.entity.User;
import com.kk.ecommerce.repository.OrderRepository;
import com.kk.ecommerce.repository.ProductRepository;
import com.kk.ecommerce.repository.UserRepository;
import com.kk.ecommerce.service.OrderService;


@Service
public class OrderServiceImpl implements OrderService {
	
	private static final Logger logger = LoggerFactory.getLogger(OrderServiceImpl.class);
	
	@Autowired
	OrderRepository orderRepository;
	@Autowired
	UserRepository userRepository;
	@Autowired
	ProductRepository productRepository;
		
	@Override
	public Order_details orderProduct(Order_details orderdetails) {
		return orderRepository.save(orderdetails);
	}
	@Override
	public Order_details getOrderDetailsById(Long user_Id) {
		List<Order_details> orderList=orderRepository.findByProduct(user_Id);
		orderList.stream().map((o1)->{
		return o1;
		}).forEach((o2)->{
			logger.info(" Order Data"+o2.getDate());
			logger.info("OrderDetails Id"+o2.getOrder_Details_id());
			logger.info("Order total Price"+o2.getTotal_price());
			logger.info("Product Id"+o2.getProduct().getProduct_Id());
			logger.info("Ordered Quanity"+o2.getQuantity());
			logger.info("Product Name"+o2.getProduct().getProductname());
		});
		return orderList.get(0);
	}
}


