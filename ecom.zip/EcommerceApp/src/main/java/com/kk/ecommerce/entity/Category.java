package com.kk.ecommerce.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotEmpty;
@Entity
public class Category {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long category_Id;
	@NotEmpty(message="Enter Category name")
	private String categoryName;
	@NotEmpty(message="Enter Category Description")
	private String category_Description;
	
	public Long getCategory_Id() {
		return category_Id;
	}
	public void setCategory_Id(Long category_Id) {
		this.category_Id = category_Id;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public String getCategory_Description() {
		return category_Description;
	}
	public void setCategory_Description(String category_Description) {
		this.category_Description = category_Description;
	}
	
	
	

}
