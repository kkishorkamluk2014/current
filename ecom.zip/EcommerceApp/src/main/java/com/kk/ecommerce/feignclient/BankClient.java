package com.kk.ecommerce.feignclient;

import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "Bank-service", url = "http://localhost:7890/fundtransfer/fundtransfers")
public interface BankClient {
	
	

}
